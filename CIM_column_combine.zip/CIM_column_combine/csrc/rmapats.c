// file = 0; split type = patterns; threshold = 100000; total count = 0.
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "rmapats.h"

void  schedNewEvent (struct dummyq_struct * I1460, EBLK  * I1455, U  I627);
void  schedNewEvent (struct dummyq_struct * I1460, EBLK  * I1455, U  I627)
{
    U  I1744;
    U  I1745;
    U  I1746;
    struct futq * I1747;
    struct dummyq_struct * pQ = I1460;
    I1744 = ((U )vcs_clocks) + I627;
    I1746 = I1744 & ((1 << fHashTableSize) - 1);
    I1455->I673 = (EBLK  *)(-1);
    I1455->I674 = I1744;
    if (0 && rmaProfEvtProp) {
        vcs_simpSetEBlkEvtID(I1455);
    }
    if (I1744 < (U )vcs_clocks) {
        I1745 = ((U  *)&vcs_clocks)[1];
        sched_millenium(pQ, I1455, I1745 + 1, I1744);
    }
    else if ((peblkFutQ1Head != ((void *)0)) && (I627 == 1)) {
        I1455->I676 = (struct eblk *)peblkFutQ1Tail;
        peblkFutQ1Tail->I673 = I1455;
        peblkFutQ1Tail = I1455;
    }
    else if ((I1747 = pQ->I1361[I1746].I696)) {
        I1455->I676 = (struct eblk *)I1747->I694;
        I1747->I694->I673 = (RP )I1455;
        I1747->I694 = (RmaEblk  *)I1455;
    }
    else {
        sched_hsopt(pQ, I1455, I1744);
    }
}
void  rmaPropagate54 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    {
        EBLK  * I1455;
        struct dummyq_struct * pQ;
        U  I1458;
        I1458 = 0;
        pQ = (struct dummyq_struct *)ref_vcs_clocks;
        if (*(scalar  *)((pcode + 0) + 24U) != val) {
            RmaEblk  * I1455 = (RmaEblk  *)(pcode + 0);
            *(scalar  *)((pcode + 0) + 24U) = val;
            if (!(I1455->I673)) {
                pQ->I1355->I673 = (EBLK  *)I1455;
                pQ->I1355 = (EBLK  *)I1455;
                I1455->I673 = (RP )((EBLK  *)-1);
                if (0 && rmaProfEvtProp) {
                    vcs_simpSetEBlkEvtID(I1455);
                }
            }
        }
    }
}
void  rmaPropagate54_t0 (UB  * pcode, UB  val)
{
    val = *(scalar  *)((pcode + 0) + 24U);
    *(scalar  *)((pcode + 0) + 24U) = 0xff;
    rmaPropagate54(pcode, val);
}
void  rmaPropagate54_s0 (UB  * pcode, scalar  val)
{
    val = *(scalar  *)((pcode + 0) + 24U);
    if (*(pcode + 48) == val) {
        return  ;
    }
    *(pcode + 48) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 56);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1184 = X4val[val];
        U  I627;
        U  I1748;
        scalar  I1627;
        U  I1749;
        U  I624;
        I624 = *(U  *)(pcode + 64);
        pcode += 72;
        scalar  out_prev_val;
        for (; I624 > 0; I624--) {
            struct dummyq_struct * pQ;
            U  I1458;
            I1458 = 0;
            pQ = (struct dummyq_struct *)ref_vcs_clocks;
            I1627 = X4val[*(scalar  *)(pcode + 81)];
            *(scalar  *)(pcode + 81) = I1184;
            I1749 = (I1627 << 2) + I1184;
            I1748 = (0x51f0 >> I1749) & 1;
            if ((I1749 & 0xa) == 0xa) {
                U  I1750;
                U  I1751;
                I1750 = ((RP  *)(pcode + 0 + 8U))[0];
                I1751 = ((RP  *)(pcode + 0 + 8U))[1];
                if (I1748) {
                    if (I1750 > I1751) {
                        I627 = I1750;
                    }
                    else {
                        I627 = I1751;
                    }
                }
                else {
                    if (I1750 > I1751) {
                        I627 = I1751;
                    }
                    else {
                        I627 = I1750;
                    }
                }
            }
            else {
                I627 = ((RP  *)(pcode + 0 + 8U))[I1748];
            }
            if (!*(UB  **)(pcode + 40)) {
                struct dummyq_struct * pQ;
                U  I1458;
                I1458 = 0;
                pQ = (struct dummyq_struct *)ref_vcs_clocks;
                *(scalar  *)(pcode + 80) = val;
                schedule_th(pQ, pcode + 24, I627);
            }
            else {
                insertNtcEventRF((RmaTransEventHdr  *)(pcode + 24), val, I1627, **(scalar  **)(pcode + 88), I627, (RP  *)(pcode + 8));
            }
            pcode += 112;
        }
    }
    {
        scalar  newval;
        U  state;
        U  startBit;
        UB  * pcode1;
        GateCount  I655;
        I655 = *(U  *)(pcode + 0);
        pcode += 8;
        for (; I655 > 0; I655--) {
            pcode1 = *(UB  **)(pcode + 8);
            {
                RP  I1569 = 1;
                if (I1569) {
                    startBit = *(U  *)(pcode + 0);
                    state = *(U  *)(pcode1 + 16U);
                    state &= ~(0x3 << startBit);
                    state |= X4val[val] << startBit;
                    *(U  *)(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 20U)) {
                        *(pcode1 + 20U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
            pcode += 16;
        }
    }
    {
        typedef
        US
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 0);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 8);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    {
        scalar  I1473;
        I1473 = val;
        (*(FP  *)(pcode + 16))(*(UB  **)(pcode + 24), I1473);
        (*(FP  *)(pcode + 32))(*(UB  **)(pcode + 40), I1473);
        (*(FP  *)(pcode + 48))(*(UB  **)(pcode + 56), I1473);
        (*(FP  *)(pcode + 64))(*(UB  **)(pcode + 72), I1473);
    }
    pcode += 80;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate87 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    val = (scalar )(((RP )pcode) & 3);
    pcode = (UB  *)((RP )pcode & ~3);
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1627;
        scalar  I1184;
        U  I1654;
        I1184 = X4val[val];
        I1627 = *(pcode + 16);
        *(pcode + 16) = I1184;
        I1654 = (I1627 << 2) + I1184;
        I1654 = 1 << I1654;
        if (I1654 & 8718) {
            *(RmaTimeStamp  *)(pcode + 24) = (RmaTimeStamp )vcs_clocks;
        }
    }
    pcode += 32;
    {
        EBLK  * I1455;
        *((*(UB  **)(pcode + 8)) + 1) = X4val[val];
        I1455 = (EBLK  *)(pcode + 0);
        if (I1455->I673 == 0) {
            struct dummyq_struct * pQ;
            U  I1458;
            I1458 = 0;
            pQ = (struct dummyq_struct *)ref_vcs_clocks;
            EBLK  * I1669 = (EBLK  *)pvcsGetLastEventEblk(I1458);
            I1455->I673 = pQ->I1388;
            pQ->I1388 = I1455;
            {
                (pQ->semilerOptQueuesFlag |= (0x1 << 2));
            }
            if (0 && rmaProfEvtProp) {
                vcs_simpSetEBlkEvtID(I1455);
            }
            I1455 = I1669;
            if (!(I1455->I673)) {
                if ((semilerOpt != 0) && (I1669 == I1455)) {
                }
                else {
                    pQ->I1377->I673 = I1455;
                    pQ->I1377 = I1455;
                }
                I1455->I673 = ((EBLK  *)-1);
                if (0 && rmaProfEvtProp) {
                    vcs_simpSetEBlkEvtID(I1455);
                }
            }
        }
    }
    {
        (*(FP  *)(pcode + 56))(*(UB  **)(pcode + 64), globalTable1Input[(*(U  *)(pcode + 48) >> 8) + val]);
    }
    {
        (*(FP  *)(pcode + 80))(*(UB  **)(pcode + 88), globalTable1Input[(*(U  *)(pcode + 72) >> 8) + val]);
    }
    pcode += 96;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate89 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    val = (scalar )(((RP )pcode) & 3);
    pcode = (UB  *)((RP )pcode & ~3);
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1473;
        I1473 = val;
        (*(FP  *)(pcode + 16))(*(UB  **)(pcode + 24), I1473);
    }
    pcode += 32;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate90 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    val = (scalar )(((RP )pcode) & 3);
    pcode = (UB  *)((RP )pcode & ~3);
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1473;
        I1473 = val;
        (*(FP  *)(pcode + 16))(*(UB  **)(pcode + 24), I1473);
        (*(FP  *)(pcode + 32))(*(UB  **)(pcode + 40), I1473);
    }
    pcode += 48;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate94 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 1U);
                }
            }
        }
    }
    pcode += 16;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate95 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1473;
        I1473 = val;
        (*(FP  *)(pcode + 16))(*(UB  **)(pcode + 24), I1473);
    }
    pcode += 32;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate95_t0 (UB  * pcode, UB  val)
{
    val = *(pcode + 0);
    *(pcode + 0) = 0xff;
    rmaPropagate95(pcode, val);
}
void  rmaPropagate103 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    val = (scalar )(((RP )pcode) & 3);
    pcode = (UB  *)((RP )pcode & ~3);
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    *(pcode + 1) = X4val[val];
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1627;
        scalar  I1184;
        U  I1654;
        I1184 = X4val[val];
        I1627 = *(pcode + 16);
        *(pcode + 16) = I1184;
        I1654 = (I1627 << 2) + I1184;
        I1654 = 1 << I1654;
        if (I1654 & 8718) {
            *(RmaTimeStamp  *)(pcode + 24) = (RmaTimeStamp )vcs_clocks;
        }
    }
    {
        scalar  I1627;
        scalar  I1184;
        U  I1654;
        US  I235;
        I1184 = X3val[val];
        I1627 = *(pcode + 32);
        I235 = (I1627 << 2) + I1184;
        I1654 = 1 << I235;
        if (I1654 & 18) {
            if (I1654 & 2) {
                (*(FP  *)(pcode + 40))(*(void **)(pcode + 48), I235);
            }
        }
        else {
            U  I1552;
            U  I657;
            U  I1733;
            U  * I1735;
            UB  * pcode1;
            pcode1 = (UB  *)(*(UP  *)(pcode + 48) & ~3);
            I657 = *(U  *)pcode1;
            I1735 = (U  *)(pcode1 + sizeof(U ));
            I1733 = (I657 + 31) >> 5;
            pcode1 += sizeof(U ) * (1 + I1733);
            for (I1552 = 0; I1552 < I1733; I1552++) {
                if (I1552 == I1733 - 1 && (I657 % 32)) {
                    I1735[I1552] = (1 << (I657 % 32)) - 1;
                }
                else {
                    I1735[I1552] = (U )-1;
                }
            }
            pcode1 = (UB  *)((((RP )pcode1) + 7) & (~7));
            for (; I657 > 0; I657--) {
                (*(FP  *)(pcode1))(*(void **)(pcode1 + 8LU), I235);
                pcode1 += 16;
            }
        }
        *(pcode + 32U) = I1184;
    }
    pcode += 56;
    {
        EBLK  * I1455;
        *((*(UB  **)(pcode + 8)) + 1) = X4val[val];
        I1455 = (EBLK  *)(pcode + 0);
        if (I1455->I673 == 0) {
            struct dummyq_struct * pQ;
            U  I1458;
            I1458 = 0;
            pQ = (struct dummyq_struct *)ref_vcs_clocks;
            EBLK  * I1669 = (EBLK  *)pvcsGetLastEventEblk(I1458);
            I1455->I673 = pQ->I1388;
            pQ->I1388 = I1455;
            {
                (pQ->semilerOptQueuesFlag |= (0x1 << 2));
            }
            if (0 && rmaProfEvtProp) {
                vcs_simpSetEBlkEvtID(I1455);
            }
            I1455 = I1669;
            if (!(I1455->I673)) {
                if ((semilerOpt != 0) && (I1669 == I1455)) {
                }
                else {
                    pQ->I1377->I673 = I1455;
                    pQ->I1377 = I1455;
                }
                I1455->I673 = ((EBLK  *)-1);
                if (0 && rmaProfEvtProp) {
                    vcs_simpSetEBlkEvtID(I1455);
                }
            }
        }
    }
    {
        (*(FP  *)(pcode + 56))(*(UB  **)(pcode + 64), globalTable1Input[(*(U  *)(pcode + 48) >> 8) + val]);
    }
    {
        typedef
        US
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 72);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 80);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    {
        typedef
        UB
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        {
            typedef
            UB
             stateType;
            typedef
            UB
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 88);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 12U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 12U) = state;
                    newval = (*(U  *)(pcode1 + 8U) >> (state << 1)) & 3;
                    if (newval != *(pcode1 + 13U)) {
                        *(pcode1 + 13U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    pcode += 96;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate105 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    val = (scalar )(((RP )pcode) & 3);
    pcode = (UB  *)((RP )pcode & ~3);
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        scalar  I1184 = X4val[val];
        U  I627;
        U  I1748;
        scalar  I1627;
        U  I1749;
        scalar  out_prev_val;
        pcode += 16;
        {
            struct dummyq_struct * pQ;
            U  I1458;
            I1458 = 0;
            pQ = (struct dummyq_struct *)ref_vcs_clocks;
            I1627 = X4val[*(scalar  *)(pcode + 81)];
            *(scalar  *)(pcode + 81) = I1184;
            I1749 = (I1627 << 2) + I1184;
            I1748 = (0x51f0 >> I1749) & 1;
            if ((I1749 & 0xa) == 0xa) {
                U  I1750;
                U  I1751;
                I1750 = ((RP  *)(pcode + 0 + 8U))[0];
                I1751 = ((RP  *)(pcode + 0 + 8U))[1];
                if (I1748) {
                    if (I1750 > I1751) {
                        I627 = I1750;
                    }
                    else {
                        I627 = I1751;
                    }
                }
                else {
                    if (I1750 > I1751) {
                        I627 = I1751;
                    }
                    else {
                        I627 = I1750;
                    }
                }
            }
            else {
                I627 = ((RP  *)(pcode + 0 + 8U))[I1748];
            }
            if (!*(UB  **)(pcode + 40)) {
                struct dummyq_struct * pQ;
                U  I1458;
                I1458 = 0;
                pQ = (struct dummyq_struct *)ref_vcs_clocks;
                *(scalar  *)(pcode + 80) = val;
                schedule_th(pQ, pcode + 24, I627);
            }
            else {
                insertNtcEventRF((RmaTransEventHdr  *)(pcode + 24), val, I1627, **(scalar  **)(pcode + 88), I627, (RP  *)(pcode + 8));
            }
        }
    }
    {
        typedef
        US
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        pcode += 112;
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 0);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 8);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    {
        scalar  I1473;
        I1473 = val;
        (*(FP  *)(pcode + 16))(*(UB  **)(pcode + 24), I1473);
    }
    pcode += 32;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate108 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    *(pcode + 1) = X4val[val];
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 1U);
                }
            }
        }
    }
    {
        typedef
        US
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 16);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
        {
            typedef
            US
             stateType;
            typedef
            US
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 24);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 16U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 16U) = state;
                    newval = *((*(UB  **)(pcode1 + 8U)) + state);
                    if (newval != *(pcode1 + 18U)) {
                        *(pcode1 + 18U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    {
        typedef
        UB
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        {
            typedef
            UB
             stateType;
            typedef
            UB
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 32);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 12U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 12U) = state;
                    newval = (*(U  *)(pcode1 + 8U) >> (state << 1)) & 3;
                    if (newval != *(pcode1 + 13U)) {
                        *(pcode1 + 13U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    pcode += 40;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate109 (UB  * pcode, scalar  val)
{
    UB  * I1812;
    if (*(pcode + 0) == val) {
        return  ;
    }
    *(pcode + 0) = val;
    {
        {
            RP  * I664 = ((void *)0);
            I664 = (RP  *)(pcode + 8);
            if (I664) {
                RP  I1666 = *I664;
                if (I1666) {
                    hsimDispatchNoDynElabS(I664, val, 0U);
                }
            }
        }
    }
    {
        typedef
        US
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        GateCount  I655;
        I655 = *(U  *)(pcode + 16);
        pcode += 24;
        for (; I655 > 0; I655--) {
            {
                typedef
                US
                 stateType;
                typedef
                US
                 * stateTypePtr;
                pcode1 = *(UB  **)(pcode + 0);
                iinput = (U )(((RP )pcode1) & 7);
                pcode1 = (UB  *)(((RP )pcode1) & ~7);
                {
                    RP  I1569 = 1;
                    if (I1569) {
                        state = *(stateTypePtr )(pcode1 + 16U);
                        state &= ~(3 << (iinput * 2));
                        state |= X4val[val] << (iinput * 2);
                        *(stateTypePtr )(pcode1 + 16U) = state;
                        newval = *((*(UB  **)(pcode1 + 8U)) + state);
                        if (newval != *(pcode1 + 18U)) {
                            *(pcode1 + 18U) = newval;
                            (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                        }
                    }
                }
            }
            pcode += 8;
        }
    }
    {
        typedef
        UB
         stateType;
        scalar  newval;
        stateType  state;
        U  iinput;
        UB  * pcode1;
        UB  * I1461;
        UB  * I1575;
        {
            typedef
            UB
             stateType;
            typedef
            UB
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 0);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 12U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 12U) = state;
                    newval = (*(U  *)(pcode1 + 8U) >> (state << 1)) & 3;
                    if (newval != *(pcode1 + 13U)) {
                        *(pcode1 + 13U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
        {
            typedef
            UB
             stateType;
            typedef
            UB
             * stateTypePtr;
            pcode1 = *(UB  **)(pcode + 8);
            iinput = (U )(((RP )pcode1) & 7);
            pcode1 = (UB  *)(((RP )pcode1) & ~7);
            {
                RP  I1569 = 1;
                if (I1569) {
                    state = *(stateTypePtr )(pcode1 + 12U);
                    state &= ~(3 << (iinput * 2));
                    state |= X4val[val] << (iinput * 2);
                    *(stateTypePtr )(pcode1 + 12U) = state;
                    newval = (*(U  *)(pcode1 + 8U) >> (state << 1)) & 3;
                    if (newval != *(pcode1 + 13U)) {
                        *(pcode1 + 13U) = newval;
                        (*(FP  *)(pcode1 + 0U))(pcode1, newval);
                    }
                }
            }
        }
    }
    {
        scalar  I1473;
        I1473 = val;
        (*(FP  *)(pcode + 16))(*(UB  **)(pcode + 24), I1473);
    }
    pcode += 32;
    UB  * I751 = *(UB  **)(pcode + 0);
    if (I751 != (UB  *)(pcode + 0)) {
        RmaSwitchGate  * I1840 = (RmaSwitchGate  *)I751;
        RmaSwitchGate  * I994 = 0;
        do {
            RmaIbfPcode  * I1115 = (RmaIbfPcode  *)(((UB  *)I1840) + 24U);
            ((FP )(I1115->I1115))((void *)I1115->pcode, val);
            RmaDoublyLinkedListElem  I1841;
            I1841.I994 = 0;
            RmaSwitchGateInCbkListInfo  I1842;
            I1842.I1305 = 0;
            I994 = (RmaSwitchGate  *)I1840->I642.I1843.I994;
        } while ((UB  *)(I1840 = I994) != (UB  *)I751);
    }
}
void  rmaPropagate109_t0 (UB  * pcode, UB  val)
{
    val = *(pcode + 0);
    *(pcode + 0) = 0xff;
    rmaPropagate109(pcode, val);
}
#ifdef __cplusplus
extern "C" {
#endif
void SinitHsimPats(void);
#ifdef __cplusplus
}
#endif
